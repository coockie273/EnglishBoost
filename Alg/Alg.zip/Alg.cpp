#include "Alg.h"
#include <QPainter>


Alg::Alg(QWidget* parent)
    : QMainWindow(parent)
{
    for (int i = 0; i < size * size; i++) {
        peaks.push_back(new Peak(i));
    }

    for (int i = 0; i < size * size - 1; i++) {
        if ((i + 1) % size == 0) {
            peaks[i]->AddCon(peaks[i + size]);
        }
        else {
            if (i + 1 < peaks.size()) {
                peaks[i]->AddCon(peaks[i + 1]);
                if (i + size < peaks.size()) {
                    peaks[i]->AddCon(peaks[i + size]);
                }
            }
        }
    }
    int space = size * size;
    do {
            int x = abs(rand() % 5) + 3;
            size_words.push_back(x);
            space -= x;
    } while (space > 6);
    size_words.push_back(space);
    TryAlg();
}

void Alg::paintEvent(QPaintEvent* e) {
    QPainter paint(this);
    QPen pen;
    int spacing = 0;
    pen.setWidth(1);
    paint.setPen(pen);
    for (int i = 0; i < size; i++) {
        paint.drawRect(101 + spacing, 15, 100, 100 * (size)); // | | |
        spacing += 100;
    }
    for (int i = 0; i < size ; i++) {
        paint.drawRect(101, 15 + i * 100, spacing, 100); /// ----
        pen.setWidth(1);
        paint.setPen(pen);
    }
    for (int i = 0; i < lines_p.size()-1; i+=2) {
        paint.drawLine(lines_p[i], lines_p[i + 1]);
    }
}

void Alg::TryAlg() {
    for (int i = 0; i < size_words.size(); i++) {
        bool yes = true;
        Peak** start;
        for (int j = 0; j < peaks.size(); j++) {
            if ((peaks[j]->GetConsCount() == 1) && (!peaks[j]->GetDone())) {
                start = &peaks[j];
                occupied_cells.push_back(j);
                yes = false;
                break;
            }
        } 
        if (yes) {
            int position = rand() % (size * size);
            while (std::find(occupied_cells.begin(), occupied_cells.end(), position) != occupied_cells.end()) {
                position = rand() % (size * size);
            }
            occupied_cells.push_back(position);
            start = &peaks[position];
        }
        for (int j = 0; j < size_words[i]-1; j++) {
            (*start)->Done();
                Peak** next_step = &(*start)->GetCons()[0];
                //int dist_to_border = 
                for (int k = 1; k < (*start)->GetConsCount(); k++) {
                    if ((*start)->GetCons()[k]->GetConsCount() < (*next_step)->GetConsCount()) {
                        next_step = &(*start)->GetCons()[k];
                    }
                }
                occupied_cells.push_back((*next_step)->GetNumber());
                lines_p.push_back(QPoint(151 + 100 * ((*start)->GetNumber() % 5), 65 + 100 * ((*start)->GetNumber() / 5)));
                lines_p.push_back(QPoint(151 + 100 * ((*next_step)->GetNumber() % 5), 65 + 100 * ((*next_step)->GetNumber() / 5)));
                (*next_step)->Done();
                start = next_step;
        }
    }
    repaint();
}