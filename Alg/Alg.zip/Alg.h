#pragma once

#include <QtWidgets/QMainWindow>
#include "Header.h"


class Alg : public QMainWindow
{
    Q_OBJECT

    int size = 5;
    std::vector<Peak*> peaks;
    std::vector<int> size_words;
    std::vector<QPoint> lines_p;
    std::vector<int> occupied_cells;
public:
    Alg(QWidget *parent = Q_NULLPTR);
    void paintEvent(QPaintEvent* e);
    void TryAlg();

};
