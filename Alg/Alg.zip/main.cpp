#include "Alg.h"
#include <QtWidgets/QApplication>

int main(int argc, char *argv[])
{
    srand(time(0));
    QApplication a(argc, argv);
    Alg w;
    w.showMaximized();
    return a.exec();
}
